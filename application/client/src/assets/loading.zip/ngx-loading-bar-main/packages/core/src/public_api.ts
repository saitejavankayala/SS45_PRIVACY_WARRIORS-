export { LoadingBarModule } from './core.module';
export { LoadingBarComponent } from './loading-bar.component';
export { LoadingBarService } from './loading-bar.service';
export { LOADING_BAR_CONFIG, LoadingBarConfig } from './loading-bar.config';
