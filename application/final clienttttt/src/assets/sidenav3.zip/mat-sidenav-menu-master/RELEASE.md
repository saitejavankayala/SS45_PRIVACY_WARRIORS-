**Release**

npm run build
cd dist/mat-sidenav-menu

*publishing a prerelease*

    npm publish 

*publishing a prerelease*

    npm publish --tag next


**GitHub credentials**

put you git authentication token in ~/.git-credentials
(https://git-scm.com/docs/git-credential-store)

