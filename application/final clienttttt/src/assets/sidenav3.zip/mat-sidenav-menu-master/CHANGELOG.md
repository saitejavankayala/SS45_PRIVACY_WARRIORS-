# 0.10.1

* (fix) add README.md to npm package
* (fix) add repo info to npm package

# 0.10.0

* update to angular/material ^7.0.0

# 0.9.0

__breaking__ 

* mat-sidenav-menu theme scss moved and renamed

    ~~@import '~mat-sidenav-menu/src/side-nav-menu/side-nav-menu-theme.scss';~~

    @import '~mat-sidenav-menu/mat-sidenav-menu-theme.scss';

* SideNavMenuModule renamed to MatSidenavMenuModule


__other modifications__

* angular cli library project structure (ng generate library ...)
* building with "ng build mat-sidenav-menu" 

# 0.8.0

* update angular/material/cli -> ^6.0.0

# 0.7.0

Breaking: 
* theming support
   * __(breaking)__ theming must be included in your application scss styles

# 0.6.0

* make the menu title modifiable

# 0.5.0

* updates material (5.2.0), angular (5.2.1)
* expasion-group (experimental, known bugs)

# 0.4.1

* update to angular 5.0.0, material 5.0.0-rc.0

# 0.4.0

Breaking: 
- routes in side-nav-item elements must begin with a slash
 

Changes: 
* fix: route activation issue
* update material to  beta.12
* use classes to style elements
* split code into more files (1 file per component)

# 0.3.0

### Features

* side-nav-group - (visual) grouping of menu items (with optional title)

# 0.2.0

### Features

* icons for menu items

# 0.1.0

### Features

* disable/enable menu item