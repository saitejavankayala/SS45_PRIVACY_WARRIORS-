/*
 * Public API Surface of mat-sidenav-menu
 */

export * from './lib/mat-sidenav-menu.component';
export * from './lib/mat-sidenav-menu.module';
